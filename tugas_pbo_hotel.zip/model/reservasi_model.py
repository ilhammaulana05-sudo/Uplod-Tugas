class ReservasiModel:
    def __init__(self):
        self.data = []

    def tambah(self, item):
        self.data.append(item)

    def semua(self):
        return self.data
