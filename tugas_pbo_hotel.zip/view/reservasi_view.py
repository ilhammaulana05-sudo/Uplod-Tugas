from rich.table import Table
from rich.console import Console

console = Console()

class ReservasiView:
    def tampilkan(self, data):
        table = Table(title="Data Reservasi")
        table.add_column("ID")
        table.add_column("Nama")
        table.add_column("Kamar")
        table.add_column("Status")

        for d in data:
            table.add_row(d["id"], d["nama"], d["kamar"], d["status"])
        console.print(table)
