from model.reservasi_model import ReservasiModel
from view.reservasi_view import ReservasiView

class ReservasiController:
    def __init__(self):
        self.model = ReservasiModel()
        self.view = ReservasiView()

    def buat_reservasi(self, id, nama, kamar, status):
        self.model.tambah({"id":id,"nama":nama,"kamar":kamar,"status":status})
        self.view.tampilkan(self.model.semua())
