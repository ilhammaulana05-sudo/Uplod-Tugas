from controller.reservasi_controller import ReservasiController

app = ReservasiController()

app.buat_reservasi("1","Dodix","101","menunggu")
app.buat_reservasi("2","Sumerz","102","konfirmasi")
app.buat_reservasi("3","Yogass","201","selesai")
app.buat_reservasi("4","Indroks","301","dibatalkan")
